/*
 * @description 
 * 
 * */

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jstring JNICALL Java_testcases_CWE111_1Unsafe_1JNI_console_CWE111_1Unsafe_1JNI_1_1console_101_test(JNIEnv *, jobject, jstring, jint);

#ifdef __cplusplus
}
#endif